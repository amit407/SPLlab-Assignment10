#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <elf.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>

int startup(int argc, char **argv, void (*start)());

int protection_flag(Elf32_Phdr* phdr) {
  int protflg = 0;
  if (phdr->p_flags & PF_R) {
    protflg |= PROT_READ;
  }
  if (phdr->p_flags & PF_W) {
    protflg |= PROT_WRITE;
  }
  if (phdr->p_flags & PF_X) {
    protflg |= PROT_EXEC;
  }
  return protflg;
}

int mapping_flag(Elf32_Phdr* phdr){
  if(phdr->p_flags & PF_W){
    return MAP_SHARED; // digit value = 1
  }
  return MAP_PRIVATE;  // digit value = 2 (MAP_FIXED)
}

void print_phdr(Elf32_Phdr* phdr){
  printf("%d\t  0x%06x  0x%x  0x%x  0x%05x   0x%05x   %d    0x%x\n",
  phdr->p_type, phdr->p_offset, phdr->p_vaddr, phdr->p_paddr, phdr->p_filesz, phdr->p_memsz, phdr->p_flags, phdr->p_align);
  int prot = protection_flag(phdr);
  int flag = mapping_flag(phdr);
  char *str = "PRIVATE";
  if (flag == 1){
    str = "SHARED";
  }
  printf("protection flag: %d. mapping flag: %d - %s \n", prot, flag, str);
}

void load_phdr(Elf32_Phdr* phdr, int fd){
  if (phdr->p_type != PT_LOAD){
    return;
  }
  int prot = protection_flag(phdr);
  int flag = mapping_flag(phdr);
  void *phdr_addrs = mmap((void*)(phdr->p_vaddr &0xfffff000), phdr->p_memsz+(phdr->p_vaddr&0xfff), prot, flag, fd, phdr->p_offset&0xfffff000);
  if (phdr_addrs == MAP_FAILED) {
    printf("mmap failed\n");
  }
  print_phdr(phdr);
}

int foreach_phdr(void *header, void (*func)(Elf32_Phdr*,int), int fd){
  printf("%s\t  %s    %s   %s   %s   %s   %s   %s\n", "Type", "Offset", "VirtAddr", "PhysAddr", "FileSiz", "MemSiz", "Flg","Align");
  Elf32_Ehdr* elfh = (Elf32_Ehdr*)header;
  for (int i = 0; i < elfh->e_phnum; i++) {
    Elf32_Phdr progHeader;
    lseek(fd, elfh->e_phoff+(i*sizeof(Elf32_Phdr)), SEEK_SET);
    read(fd, &progHeader, sizeof(Elf32_Phdr));
    func(&progHeader, fd);
  }
  return 0;
}

int main(int argc, char **argv){
  char *fileName = argv[1];
  int fd = open(fileName,O_RDWR);
  if (fd == -1){
    fprintf(stderr, "Error: file not opened\n");
    exit(-1);
  }
  Elf32_Ehdr header;
  read(fd, &header, sizeof(Elf32_Ehdr));
  int output = foreach_phdr(&header, load_phdr, fd);
  startup(argc-1, argv+1, (void *)(header.e_entry));
  return(output);
}
